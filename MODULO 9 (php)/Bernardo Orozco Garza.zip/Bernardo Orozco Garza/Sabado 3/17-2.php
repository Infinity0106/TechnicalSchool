<?php 
$conexion=mysql_connect("localhost","root","") or die("Problemas en la conexion");
mysql_select_db("mi_tiendita",$conexion) or die("Problemas en la conexion de la base de datos");
mysql_query("insert into productos(nombre, descripcion, precio, departamento)
values ('$_REQUEST[nombre]','$_REQUEST[descripcion]','$_REQUEST[precio]','$_REQUEST[departamento]')",$conexion) or die("Problemas en el select".mysql_error());
mysql_close($conexion);
ht
?>