<!DOCTYPE html>
<html>
<head>
	<title>Pagina 17-1</title>
</head>
<body>
	<h1>Alta de productos</h1>
	<form action="17-2.php" method="post">
	Ingrese el nombre:
		<input type="text" name="nombre"><br>
	Agregue una breve descripcion del producto: <br>
		<textarea rows="10" cols="60" name="descripcion"></textarea><br>
	Ingrese el precio:
		<input type="number" name="precio"><br>
	Selecione el departamento:
		<select name="departamento">
			<option value="1"></option>
			<option value="2">Electronica</option>
			<option value="3">Ferreteria</option>
			<option value="4">Farmacia</option>
			<option value="5">Panaderia</option>
			<option value="6">Papeleria</option>
			<option value="7">Frutas y Verduras</option>
		</select>
		<br>
		<input type="submit" value="Insertar">
	</form>
</body>
</html>