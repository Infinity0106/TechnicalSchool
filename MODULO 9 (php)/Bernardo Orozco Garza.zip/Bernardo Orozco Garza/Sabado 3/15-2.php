<?php
$nom= $_REQUEST['nombre'];
if($_REQUEST['opt']=='entrada'){
	echo 'Hola '.$nom.' bienvenido(a) al curso';
}
elseif ($_REQUEST['opt']=='salida'){
	echo 'Adios, '.$nom." nos vemos el proximo sabado.";
}
else {
	echo 'Seleciona una opcion';
}
?>