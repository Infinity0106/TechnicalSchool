<!DOCTYPE html>
<html>
<head>
<title>Pagina 16-1</title>
<style>
html{width:80%;margin:0 auto;}
</style>
</head>
<body>
<h1>Sign-in</h1>
<hr>
<form action="16-2.php">
<input placeholder="Nombre" required type="text" maxlength="10" name="0"><br>
<input placeholder="Apellido" required type="text" maxlength="10" name="1"><br>
<input placeholder="Edad" required type="number" name="2"><br>
<input placeholder="Direccion" type="text" maxlength="10" name="3"><br>
<input placeholder="C.P." type="number" name="4"><br>
<input placeholder="Municipio" type="text" maxlength="10" name="5"><br>
<input type="file" name='6'><br>
<input type="submit" value="Enviar">
</form>

</body>
</html>