<!DOCTYPE html>
<html>
<head>
<title>Pagina 15</title>
</head>
<body>
<form action="15-2.php">
	Ingresa tu nombre: <input type="text" maxlength='25' size='25' name='nombre' placeholder='tu nombre'><br>
	<input type="radio" value="entrada" name='opt'>Entrada<br>
	<input type="radio" value="salida" name='opt'>Salida<br>
	<input type="submit" value='Aceptar'>
</form>
</body>
</html>