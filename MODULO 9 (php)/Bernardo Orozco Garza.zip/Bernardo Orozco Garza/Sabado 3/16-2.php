<?php 
for($i=0;$i<7;$i++){
	if($_REQUEST[$i]==""){
		$_REQUEST[$i]='null';
	}
}
echo "<head>
<title>pagina 16-2</title>
<style>
html{width: 80%; margin: 0 auto;}
</style>
</head>
<h1>User Information</h1>
<hr>
<table border='2'>
	<thead>
	<tr>
	<th>Nombre</th>
	<th>Apellido</th>
	<th>Edad</th>
	<th>Direccion</th>
	<th>Codigo Postal</th>
	<th>Municipio</th>
	<th>Archivo</th>
	</tr>
	</thead>
	<tbody>
	<tr>
	<td>".$_REQUEST['0']."</td>
	<td>".$_REQUEST['1']."</td>
	<td>".$_REQUEST['2']."</td>
	<td>".$_REQUEST['3']."</td>
	<td>".$_REQUEST['4']."</td>
	<td>".$_REQUEST['5']."</td>
	<td>".$_REQUEST['6']."</td>
	</tr>
	</tbody>
</table>";

?>