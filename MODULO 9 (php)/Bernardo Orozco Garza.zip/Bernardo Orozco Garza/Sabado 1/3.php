<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 3</title>
	</head>
	<body>
		<?php 
			header('content-type: text/html; charset=UTF-8');
			$edad = 18;
			$nombre="Bernardo";
			$modulo="modulo 9: PHP";
			echo '<p>Hola, mi nombre es '.$nombre.' y tengo '.$edad.' a&ntilde;os, curso el '.$modulo;
		?>
	</body>
</html>