<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 5</title>
	</head>
	<body>
		<?php 
		function todo(){
			//funcion de usuario
			echo'<h1>Funciones del usuario</h1>';
			$edad = 18;
			$nombre="Bernardo";
			$modulo="modulo 9: PHP";
			echo '<p>Hola, mi nombre es '.$nombre.' y tengo '.$edad.' a&ntilde;os, curso el '.$modulo;
			
			$num1=rand(0, 999);
			$num2=rand(0, 999);
			$suma=$num1+$num2;
			$mult=$suma*4;
			echo '<br>'.$num1.' + '.$num2.' = '.$suma.'<br>'.$suma.' X 4 = '.$mult;
			/*funcion del sistema*/
			echo '<br><h1>Funciones del usuario</h1>';
			$dia=date("d - M - Y");
			$absnum=rand(-1, -999);
			$abs=abs($absnum);
			$max=max(rand(0, 10),rand(0, 10),rand(0, 10),rand(0, 10));
			$raiz=sqrt(rand(0, 100));
			echo 'Date() = '.$dia.'<br>ABS = '.$abs.'<br>MAX = '.$max.'<br>&sqrt;(rand()) = '.$raiz;
		}
		todo();
		?>
	</body>
</html>