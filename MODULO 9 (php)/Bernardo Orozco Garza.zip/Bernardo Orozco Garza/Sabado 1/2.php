<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 2</title>
	</head>
	<body>
		<?php 
			echo '<p>Tecnico desarrollador de software<br>';
			print ('modulo 9: PHP<br>');
			echo 'Bernardo Orozco Garza <br>';
			print ('no me la se :) </p>');
		?>
	</body>
</html>