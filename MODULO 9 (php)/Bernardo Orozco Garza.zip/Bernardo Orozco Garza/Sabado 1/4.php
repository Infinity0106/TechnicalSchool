<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 4</title>
	</head>
	<body>
		<?php 
			$num1=rand(0, 999);
			$num2=rand(0, 999);
			$suma=$num1+$num2;
			$mult=$suma*4;
			echo $num1.' + '.$num2.' = '.$suma.'<br>'.$suma.' X 4 = '.$mult;
		?>
	</body>
</html>