<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 6</title>
	</head>
	<body>
		<?php 
			suma(7,6,9);
			function suma($num1,$num2,$num3){
				$suma=$num1+$num2+$num3;
				echo $num1.' + '.$num2.' + '.$num3.' = '.$suma;
			}
			mult(4,6,9);
			function mult($num1,$num2,$num3){
				$mult=$num1*$num2*$num3;
				echo '<br>'.$num1.' X '.$num2.' X '.$num3.' = '.$mult;
			}
		?>
	</body>
</html>