<!DOCTYPE html>
<html>
	<head>
		<title>Creando mi pagina en PHP</title>
	</head>
	<body>
		<?php
			echo '<p>Hola Mundo</p>'
		?>
	</body>
</html>