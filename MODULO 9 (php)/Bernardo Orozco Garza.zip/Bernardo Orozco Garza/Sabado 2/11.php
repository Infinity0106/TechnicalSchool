<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 11</title>
	</head>
	<body>
		<?php
			$dia=date("w");
			switch ($dia){
				case 1:
					echo 'Feliz lunes';
					break;
				case 2:
					echo 'Feliz martes';
					break;
				case 3:
					echo 'Feliz miercoles';
					break;
				case 4:
					echo 'Feliz jueves';
					break;
				case 5:
					echo 'Feliz viernes';
					break;
				case 6:
					echo 'Feliz sabado';
					break;
				case 7:
					echo 'Feliz domingo';
					break;
				default:
					echo 'error';
					break;
			}
		?>
	</body>
</html>