<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 7</title>
	</head>
	<body>
		<?php 
			//comparar dos numeros
			$num1=6;
			$num2=4;
			if ($num1>$num2){print ($num1." es mayor que ".$num2);}
			elseif ($num2==$num1){echo $num1.' es igual que '.$num2;}
			else {print($num2." es mayor que ".$num1);}
		?>
	</body>
</html>