<!DOCTYPE html>
<html>
	<head>
		<title>sentencias</title>
		<style>
			#left{
				float: left;
    			margin-left: 2%;
    			width: 30%;
    			background-color: green;
    			border-radius: 10px;
    			padding: 0 5px 2px 5px;
			}
			#center{
				float: left;
    			width: 30%;
    			height: auto;
    			background-color: grey;
    			border-radius: 10px;
    			padding: 0 5px 2px 5px;
    			margin: 0 2%;
			}
			#right{
				float: left;
				width: 30%;
				margin-right: 2%;
				background-color: green;
				border-radius: 10px;
				padding: 0 5px 2px 5px;
			}
		</style>
	</head>
	<body>
		<h1><center>Sencias</center></h1>
		<div id='left'>
			<h2>IF</h2>
			<?php include '8.php'; ?>
		</div>
		<div id='center'>
			<h2>FOR</h2>
			<?php include '10.php'; ?>
		</div>
		<div id='right'>
			<h2>SWITCH</h2>
			<?php include '11.php'; ?>
		</div>
	</body>
</html>