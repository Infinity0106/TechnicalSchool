<?php
if($_REQUEST['num1']>$_REQUEST['num2']){
	echo 'el numero '.$_REQUEST['num1'].' es mayor a '.$_REQUEST['num2'];
}
elseif ($_REQUEST['num2']==$_REQUEST['num1']){
	echo "el numero ".$_REQUEST['num1']." es igual a ".$_REQUEST['num2'];
}
else{
	echo 'el numero '.$_REQUEST['num2'].' es mayor a '.$_REQUEST['num1'];
}
$sum=$_REQUEST['num1']+$_REQUEST['num2'];
echo "<br>".$sum;
?>