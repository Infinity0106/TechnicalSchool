<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 9</title>
	</head>
	<body>
		<form method="post" action='menu.php'>
		<select name="platillo">
			<option value="1">chile relleno</option>
			<option value="2">discada</option>
			<option value="3">tortas</option>
			<option value="4">enchiladas</option>
			<option value="5">pechuga rellena</option>
		</select>
		<select name="bebida">
			<option value="1">Refresco</option>
			<option value="2">Agua</option>
			<option value="3">Limonada</option>
			<option value="4">Naranjada</option>
		</select>
		<input type="submit" value='confirmar'>
		</form>
	</body>
</html>