<?php
ejercicio1();
echo '<br><br>';
ejercicio2();

function ejercicio1(){
	$cal=rand(0,100);
	if($cal>=70){
		echo "Felicicdades has aprobado con <b>".$cal."</b>";
	}
	else {
		echo "has reprobado con <b>".$cal."</b>";
	}
}

function ejercicio2 (){
	$temp= rand(-10, 50);
	if ($temp>20){
		echo 'clima fresco';
	}
	elseif ($temp==20){
		echo "temperatura agradable";
	}
	else{
		echo "hace calor";
	}
}
?>