<?php
echo 'El nombre ingresado es: '.$_REQUEST['nombre'].' '.$_REQUEST['apellido'];
echo '<br>Matriucla: '.$_REQUEST['matricula'];
echo '<br>Edad: '.$_REQUEST['edad'];
?>