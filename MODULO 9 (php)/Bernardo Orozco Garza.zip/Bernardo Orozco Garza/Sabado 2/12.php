<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<form>
			<input name='nombre' type="text" size="20" maxlength="20" placeholder='nombre'>
			<input name='contrasena' type='password' size='' maxlength='20'>
			<input name='leer' type="checkbox">
			<input name='jugar' type="checkbox">
			<input name='deportes' type="checkbox" checked>
			<input name='otro' type="checkbox">
			<input type="radio" name='opt' value='4'>1
			<input type="radio" name='opt' value='4'>2
			<input type="radio" name='opt' value='4'>3
			<input type="radio" name='opt' value='4'>4
			<textarea name='comentarios' rows="10" cols="15"></textarea>
			<select name='opt2'>
				<option value='1'>HOLA</option>
				<option value='2'>MUNDO</option>
				<option value='3'>BLA</option>
				<option value='4'>BLA BLA</option>
			</select>
		</form>
	</body>
</html>