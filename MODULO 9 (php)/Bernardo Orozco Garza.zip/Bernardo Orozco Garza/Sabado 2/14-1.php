<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 2</title>
	</head>
	<body>
		<form method="get" action='14-2.php'>
		numero 1:
			<input type='text' size='4' maxlength='3' name='num1'><br>
		numero 2:
			<input type='text' size='4' maxlength='3' name='num2'>
			<input type="submit" value="Confirmar">
		</form>
	</body>
</html>