<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 13</title>
	</head>
	<body>
		<form action="13-2.php" method="get">
			INGRESE SU NOMBRE:
			<input name='nombre' type='text' size='20' maxlength='15'>
			<br>
			APELLIDO:
			<input type="text" size='20' maxlength='15' name='apellido'>
			MATRICULA:
			<input type="text" size='7' maxlength='7' name='matricula'>
			EDAD:
			<input type="text" size='4' maxlength='3' name='edad'>
			<input type="submit" value='confirmar'>
		</form>
	</body>
</html>