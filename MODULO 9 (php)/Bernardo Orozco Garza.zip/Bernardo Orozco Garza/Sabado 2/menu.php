<?php

		$opt1= $_REQUEST['platillo'];
		$opt2= $_REQUEST['bebida'];
			switch ($opt1){
				case 1:
					$precio1=50;
					break;
				case 2:
					$precio1=45;
					break;
				case 3:
					$precio1=53;
					break;
				case 4:
					$precio1=48;
					break;
				case 5:
					$precio1=51;
					break;
				default:
					echo 'Error platillo no seleccionado';
					break;
			}
			switch ($opt2){
				case 1:
					$precio2=15;
					break;
				case 2:
					$precio2=17;
					break;
				case 3:
					$precio2=25;
					break;
				case 4:
					$precio2=25;
					break;
				default:
					echo 'Error bebida no seleccionada';
					break;
			}
			$tot= $precio1 + $precio2;
			echo $tot;
		?>