<!DOCTYPE html>
<html>
	<head>
		<title>Pagina 10</title>
	</head>
	<body>
		<?php
			for($i=1;$i<=10;$i++){
				echo $i." ";
			}
			echo '<br>';
			for($i=1;$i<=100;$i++){
				echo $i." ";
			}
		?>
	</body>
</html>